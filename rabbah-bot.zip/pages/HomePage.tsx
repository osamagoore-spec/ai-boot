
import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { GoogleGenAI, Chat } from "@google/genai";

// --- Icons ---

const CheckIcon = () => (
  <svg className="w-5 h-5 text-[#7B61FF] flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
  </svg>
);

const StarIcon = () => (
  <svg className="w-4 h-4 text-yellow-400 fill-current" viewBox="0 0 20 20">
    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
  </svg>
);

// --- Components ---

const FAQItem: React.FC<{ question: string; answer: string }> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="border-b border-gray-100 last:border-0">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center py-6 text-right focus:outline-none hover:text-[#7B61FF] transition-colors"
      >
        <h4 className="text-lg font-bold text-[#111827]">{question}</h4>
        <span className={`transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''} text-[#7B61FF]`}>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" /></svg>
        </span>
      </button>
      <div className={`overflow-hidden transition-all duration-300 ${isOpen ? 'max-h-48 opacity-100 pb-6' : 'max-h-0 opacity-0'}`}>
        <p className="text-gray-600 leading-relaxed">
           {answer}
        </p>
      </div>
    </div>
  );
};

// --- Interactive Demo Bot ---

interface Message {
    role: 'user' | 'model';
    text: string;
}

const InteractiveDemoBot = () => {
    const [messages, setMessages] = useState<Message[]>([
        { role: 'model', text: 'يا هلا! 👋 أنا ربّاح. اسألني أي شيء عن خدماتي وراح أجاوبك فوراً 👇' }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const chatRef = useRef<Chat | null>(null);
    const chatContainerRef = useRef<HTMLDivElement>(null);

    const suggestions = [
        "كم الأسعار؟ 💰",
        "كيف أركبه بمتجري؟ 🛠️",
        "هل يدعم سلة وزد؟ 🛒",
        "وش مميزاتك؟ ✨"
    ];

    useEffect(() => {
        if (chatContainerRef.current) {
            chatContainerRef.current.scrollTo({
                top: chatContainerRef.current.scrollHeight,
                behavior: 'smooth'
            });
        }
    }, [messages, isLoading]);

    useEffect(() => {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        chatRef.current = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: {
                systemInstruction: `أنت "ربّاح بوت"، زر دردشة عائم ذكي يركب على المتاجر الإلكترونية.
                أنت من تطوير "منصة ربّاح".
                طريقة عملك: يتم ربطك بالمتجر (مثل سلة أو زد) وتظهر فوراً للعملاء لخدمتهم والرد على استفساراتهم عن المنتجات والطلبات.
                تحدث بلهجة سعودية ودودة ومختصرة جداً.
                مهمتك هي إقناع صاحب المتجر (الذي يجربك الآن) بأنك الحل الأمثل لخدمة العملاء وزيادة المبيعات.
                أكد له أنك لست مجرد بوت عادي، بل زر ذكي يتكامل مع متجره.
                استخدم الإيموجي باعتدال.`
            }
        });
    }, []);

    const sendMessage = async (text: string) => {
        if (!text.trim() || isLoading) return;

        const userMsg = text;
        setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
        setIsLoading(true);

        try {
            if (chatRef.current) {
                const result = await chatRef.current.sendMessage({ message: userMsg });
                setMessages(prev => [...prev, { role: 'model', text: result.text }]);
            }
        } catch (error) {
            setMessages(prev => [...prev, { role: 'model', text: 'معليش، صار خطأ تقني بسيط. جرب مرة ثانية! 🙏' }]);
        } finally {
            setIsLoading(false);
        }
    };

    const handleSend = (e?: React.FormEvent) => {
        e?.preventDefault();
        if(input.trim()) {
            sendMessage(input);
            setInput('');
        }
    };

    return (
        <div className="w-full max-w-[320px] mx-auto bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden h-[480px] flex flex-col relative z-20 transform transition-all hover:shadow-[#7B61FF]/20">
            {/* Header */}
            <div className="bg-gradient-to-r from-[#7B61FF] to-[#9E7BFF] p-4 flex items-center justify-between text-white shadow-md shrink-0">
                <div className="flex items-center gap-3">
                    <div className="relative">
                        <div className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white text-xl border border-white/30 shadow-inner">
                            🤖
                        </div>
                        <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-[#10B981] border-2 border-[#7B61FF] rounded-full"></div>
                    </div>
                    <div>
                        <h3 className="font-bold text-sm">اسم متجرك</h3>
                        <p className="text-[10px] opacity-90 font-light flex items-center gap-1">
                            <span className="w-1 h-1 bg-white rounded-full animate-pulse"></span>
                            يرد خلال ثواني
                        </p>
                    </div>
                </div>
            </div>

            {/* Messages */}
            <div ref={chatContainerRef} className="flex-1 p-3 overflow-y-auto bg-[#F9FAFB] space-y-3 custom-scrollbar">
                <div className="text-center text-[10px] text-gray-400 font-medium my-2 bg-gray-200/50 w-fit mx-auto px-3 py-1 rounded-full">اليوم</div>
                {messages.map((msg, idx) => (
                    <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in-up`}>
                        <div className={`max-w-[85%] p-3 rounded-2xl text-sm leading-relaxed shadow-sm ${
                            msg.role === 'user' 
                            ? 'bg-[#7B61FF] text-white rounded-br-none' 
                            : 'bg-white text-gray-800 rounded-bl-none border border-gray-100'
                        }`}>
                            {msg.text}
                        </div>
                    </div>
                ))}
                {isLoading && (
                    <div className="flex justify-start">
                        <div className="bg-white p-3 rounded-2xl rounded-bl-none shadow-sm border border-gray-100">
                           <div className="flex gap-1">
                                <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce"></div>
                                <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce delay-75"></div>
                                <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce delay-150"></div>
                           </div>
                        </div>
                    </div>
                )}
            </div>

            {/* Suggestions */}
            <div className="px-3 pt-2 bg-[#F9FAFB]">
                <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar" style={{scrollbarWidth: 'none'}}>
                    {suggestions.map((s, i) => (
                        <button 
                            key={i} 
                            onClick={() => sendMessage(s)}
                            disabled={isLoading}
                            className="whitespace-nowrap px-3 py-1.5 bg-white border border-[#7B61FF]/20 text-[#7B61FF] text-xs rounded-full hover:bg-[#7B61FF] hover:text-white transition-colors shadow-sm shrink-0"
                        >
                            {s}
                        </button>
                    ))}
                </div>
            </div>

            {/* Input */}
            <div className="p-3 bg-white border-t border-gray-100 shrink-0">
                <form onSubmit={handleSend} className="relative flex items-center gap-2">
                    <input 
                        type="text" 
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="اكتب سؤالك هنا..."
                        className="flex-1 bg-gray-50 text-gray-800 rounded-full py-2.5 px-4 focus:outline-none focus:ring-2 focus:ring-[#7B61FF]/20 focus:bg-white transition-all border border-gray-200 text-sm"
                    />
                    <button 
                        type="submit" 
                        disabled={!input.trim() || isLoading}
                        className={`w-10 h-10 rounded-full flex items-center justify-center transition-all transform hover:scale-105 active:scale-95 shadow-sm ${
                            input.trim() ? 'bg-[#7B61FF] text-white hover:bg-[#6b53e3]' : 'bg-gray-100 text-gray-300'
                        }`}
                    >
                        <svg className="w-5 h-5 transform rotate-180 ml-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
                    </button>
                </form>
            </div>
        </div>
    );
};

const HomePage: React.FC = () => {
    
  const handleContactSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    alert('تم الاستلام! شكراً لتواصلك معنا.');
    e.currentTarget.reset();
  };

  return (
    <div className="font-sans text-[#111827] selection:bg-[#7B61FF] selection:text-white">
      
      {/* --- HERO SECTION --- */}
      <section id="hero" className="relative pt-24 pb-24 lg:pt-32 lg:pb-40 overflow-hidden">
        {/* Background Gradients */}
        <div className="absolute inset-0 bg-gradient-to-b from-purple-50/50 via-white to-white -z-20"></div>
        <div className="absolute top-0 right-0 w-[40%] h-[60%] bg-purple-100/40 rounded-full blur-[100px] -z-10 opacity-60"></div>
        <div className="absolute bottom-0 left-0 w-[40%] h-[60%] bg-blue-100/40 rounded-full blur-[100px] -z-10 opacity-60"></div>

        <div className="container mx-auto px-6">
            <div className="flex flex-col lg:flex-row items-center gap-8 lg:gap-10">
                
                {/* Text Content */}
                <div className="w-full lg:w-1/2 text-center lg:text-right z-10">
                    <div className="inline-flex items-center gap-2.5 px-5 py-2 rounded-full bg-white border border-purple-100 text-[#7B61FF] font-bold text-sm mb-8 shadow-sm hover:shadow-md transition-shadow cursor-default">
                        <span className="flex h-2.5 w-2.5 relative">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#7B61FF]"></span>
                        </span>
                        متوافق 100% مع متاجر زد وسلّة
                    </div>
                    
                    <h1 className="text-5xl lg:text-7xl font-extrabold text-[#111827] leading-[1.1] mb-8 tracking-tight">
                        زر ذكاء اصطناعي <br/>
                        <span className="gradient-text relative inline-block">
                            عائم
                            <svg className="absolute w-full h-3 -bottom-1 left-0 text-purple-200 -z-10" viewBox="0 0 100 10" preserveAspectRatio="none"><path d="M0 5 Q 50 10 100 5" stroke="currentColor" strokeWidth="8" fill="none" /></svg>
                        </span> يخدم عملاء متجرك
                    </h1>
                    
                    <p className="text-xl text-gray-600 mb-10 leading-relaxed max-w-2xl mx-auto lg:mx-0">
                        "ربّاح" ليس مجرد بوت خارجي، هو <strong className="text-[#111827] font-bold">أداة عائمة (Widget)</strong> ذكية تركبها في متجرك، تستقبل الزوار، تجاوب أسئلتهم، وتقنعهم بالشراء دون مغادرة الصفحة.
                    </p>
                    
                    <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-5 mb-12">
                        <Link to="/#pricing" className="w-full sm:w-auto px-10 py-4 bg-[#7B61FF] hover:bg-[#654de0] text-white text-lg font-bold rounded-2xl transition-all transform hover:-translate-y-1 shadow-lg shadow-purple-200 ring-4 ring-purple-50 text-center">
                            ركّب البوت الآن
                        </Link>
                        <Link to="/#features" className="w-full sm:w-auto px-10 py-4 bg-white border border-gray-200 text-gray-700 font-bold rounded-2xl hover:bg-gray-50 hover:text-[#7B61FF] hover:border-purple-200 transition-all text-center shadow-sm">
                            كيف يفيدك؟
                        </Link>
                    </div>

                    {/* Trusted By Section */}
                    <div className="flex flex-col items-center lg:items-start gap-4 border-t border-gray-100 pt-8">
                         <p className="text-sm text-gray-500 font-bold uppercase tracking-wide">موثوق من أكثر من <strong className="text-[#111827]">+200 متجر</strong></p>
                         <div className="flex items-center gap-6">
                             <div className="flex -space-x-4 rtl:space-x-reverse">
                                {[1,2,3,4].map((i) => (
                                    <img key={i} className="w-12 h-12 rounded-full border-[3px] border-white shadow-md ring-1 ring-gray-100 bg-gray-50" src={`https://api.dicebear.com/9.x/identicon/svg?seed=${i + 55}`} alt="Store Owner" />
                                ))}
                                <div className="w-12 h-12 rounded-full border-[3px] border-white bg-gray-50 flex items-center justify-center text-xs font-black text-gray-500 ring-1 ring-gray-100 shadow-md">+200</div>
                            </div>
                            <div className="h-10 w-px bg-gray-200 hidden sm:block"></div>
                            <div className="flex flex-col gap-1">
                                <div className="flex text-yellow-400">
                                    {[1,2,3,4,5].map(i => <StarIcon key={i} />)}
                                </div>
                                <span className="text-xs font-bold text-gray-400">تقييم 4.9/5 من التجار</span>
                            </div>
                         </div>
                    </div>
                </div>

                {/* Visual Content */}
                <div className="w-full lg:w-1/2 flex justify-center lg:justify-center relative lg:pr-20">
                     
                     <div className="flex flex-col lg:flex-row items-center relative z-10 perspective-1000">
                        {/* Bubble Badge */}
                        <div className="bg-white py-4 px-6 rounded-full shadow-xl border border-purple-50 absolute top-24 left-full ml-6 z-30 hidden lg:flex items-center gap-3 animate-bounce-slow w-max transform transition-transform hover:scale-105">
                            <p className="text-sm font-bold text-[#111827] whitespace-nowrap">
                                <span className="text-[#7B61FF]">جرّب الحين!</span> وشوف كيف راح يظهر البوت في متجرك
                            </p>
                            <span className="text-2xl">💡</span>
                             {/* Arrow */}
                            <div className="absolute top-1/2 -left-2 -translate-y-1/2 w-4 h-4 bg-white transform rotate-45 border-l border-b border-purple-50"></div>
                        </div>

                        <InteractiveDemoBot />
                        
                        {/* Decorative elements behind bot */}
                        <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-yellow-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
                        <div className="absolute -left-8 -top-8 w-32 h-32 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
                    </div>
                </div>
            </div>
        </div>
      </section>

      {/* --- VALUE PROPOSITION --- */}
      <section className="py-24 bg-[#F8F9FC]">
          <div className="container mx-auto px-6">
              <div className="text-center max-w-3xl mx-auto mb-20">
                  <h2 className="text-3xl md:text-4xl font-extrabold text-[#111827] mb-6">ليش الزر العائم أفضل لمتجرك؟</h2>
                  <p className="text-gray-500 text-xl leading-relaxed">لأن العميل ما يحب يشتت انتباهه ويطلع من المتجر عشان يسأل. خلك جنبه دائماً.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                  <div className="bg-white p-10 rounded-3xl shadow-sm border border-gray-100 hover:shadow-xl hover:shadow-purple-500/5 hover:-translate-y-2 transition-all duration-300 group">
                      <div className="w-16 h-16 bg-purple-50 rounded-2xl flex items-center justify-center mb-8 text-[#7B61FF] group-hover:bg-[#7B61FF] group-hover:text-white transition-colors">
                          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
                      </div>
                      <h3 className="text-2xl font-bold mb-4 text-[#111827]">دايم قدام عين العميل</h3>
                      <p className="text-gray-500 leading-relaxed text-lg">أيقونة صغيرة في زاوية الشاشة، موجودة في كل صفحات المتجر، جاهزة للمساعدة بضغطة زر.</p>
                  </div>
                  <div className="bg-white p-10 rounded-3xl shadow-sm border border-gray-100 hover:shadow-xl hover:shadow-blue-500/5 hover:-translate-y-2 transition-all duration-300 group">
                      <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mb-8 text-[#22D3EE] group-hover:bg-[#22D3EE] group-hover:text-white transition-colors">
                          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" /></svg>
                      </div>
                      <h3 className="text-2xl font-bold mb-4 text-[#111827]">ما يغادر المتجر أبداً</h3>
                      <p className="text-gray-500 leading-relaxed text-lg">المحادثة تتم فوق صفحة المتجر (Overlay)، يعني العميل يقدر يسأل ويشتري وهو في نفس المكان.</p>
                  </div>
                  <div className="bg-white p-10 rounded-3xl shadow-sm border border-gray-100 hover:shadow-xl hover:shadow-pink-500/5 hover:-translate-y-2 transition-all duration-300 group">
                      <div className="w-16 h-16 bg-pink-50 rounded-2xl flex items-center justify-center mb-8 text-pink-400 group-hover:bg-pink-400 group-hover:text-white transition-colors">
                          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                      </div>
                      <h3 className="text-2xl font-bold mb-4 text-[#111827]">ذكاء يفهم السياق</h3>
                      <p className="text-gray-500 leading-relaxed text-lg">يعرف المنتج اللي العميل يتصفحه حالياً، ويقدر يعطي تفاصيل عنه ويقترح بدائل.</p>
                  </div>
              </div>
          </div>
      </section>

      {/* --- FEATURES GRID --- */}
      <section id="features" className="py-24 bg-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-50/50 rounded-full blur-3xl -z-10 translate-x-1/2 -translate-y-1/2"></div>
        <div className="container mx-auto px-6">
            <div className="text-center mb-20">
                <span className="inline-block px-3 py-1 bg-purple-50 text-[#7B61FF] font-bold tracking-wider text-sm rounded-full mb-4">المميزات</span>
                <h2 className="text-3xl md:text-4xl font-extrabold text-[#111827]">كل اللي يحتاجه متجرك وأكثر</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {[
                    { title: "تفعيل فوري", desc: "اربط حسابك في زد أو سلّة وخلال دقيقة البوت يكون ظاهر في متجرك.", icon: "⚡️" },
                    { title: "لهجة سعودية", desc: "يفهم الكلام الدارج (كم يكلف؟ وش الوضع؟) ويرد بأسلوب محلي ومحبوب.", icon: "🇸🇦" },
                    { title: "أتمتة المبيعات", desc: "يقدر يرسل روابط المنتجات وروابط الدفع مباشرة داخل المحادثة.", icon: "💸" },
                    { title: "تخصيص كامل", desc: "غيّر لون الأيقونة، اسم البوت، ورسالة الترحيب عشان تناسب هوية متجرك.", icon: "🎨" },
                    { title: "تقارير ذكية", desc: "اعرف وش يسألون عنه عملائك، ووين المشاكل اللي تواجههم.", icon: "📊" },
                    { title: "دعم بشري", desc: "تقدر تتدخل في المحادثة أي وقت وتكمل مع العميل بنفسك لو حبيت.", icon: "🎧" }
                ].map((feature, i) => (
                    <div key={i} className="bg-white p-8 rounded-3xl border border-gray-100 hover:border-[#7B61FF]/50 hover:shadow-lg hover:shadow-purple-500/5 transition-all group">
                        <div className="text-5xl mb-6 transform group-hover:scale-110 transition-transform duration-300">{feature.icon}</div>
                        <h3 className="text-xl font-bold mb-3 text-[#111827]">{feature.title}</h3>
                        <p className="text-gray-500 leading-relaxed">{feature.desc}</p>
                    </div>
                ))}
            </div>
        </div>
      </section>

      {/* --- HOW IT WORKS --- */}
      <section className="py-24 bg-[#F8F9FC]">
          <div className="container mx-auto px-6">
              <div className="text-center mb-20">
                  <h2 className="text-3xl md:text-4xl font-extrabold text-[#111827]">كيف يظهر في متجري؟</h2>
                  <p className="text-gray-500 mt-4 text-xl">الموضوع أسهل مما تتخيل، ثلاث خطوات بس.</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12">
                  {[
                      { step: "01", title: "اختر باقتك", desc: "سجل في المنصة واختر الباقة اللي تناسب حجم متجرك." },
                      { step: "02", title: "اربط المتجر", desc: "بضغطة زر، اسمح لربّاح بالوصول لمنتجاتك في زد أو سلّة." },
                      { step: "03", title: "ومبروك!", desc: "الزر العائم بيظهر تلقائياً في متجرك ويبدأ يستقبل العملاء." }
                  ].map((item, i) => (
                      <div key={i} className="bg-white p-10 rounded-3xl shadow-sm border border-gray-100 text-center relative overflow-hidden group hover:-translate-y-2 transition-all duration-300">
                          <div className="text-8xl font-black text-gray-50 absolute -top-4 -right-4 -z-0 transition-transform group-hover:scale-110 group-hover:text-purple-50/50">{item.step}</div>
                          <div className="relative z-10">
                             <div className="w-14 h-14 bg-[#7B61FF] rounded-2xl flex items-center justify-center mx-auto mb-6 text-white text-xl font-bold shadow-lg shadow-purple-200">
                                 {i+1}
                             </div>
                             <h3 className="text-2xl font-bold mb-3 text-[#111827]">{item.title}</h3>
                             <p className="text-gray-500 text-lg">{item.desc}</p>
                          </div>
                      </div>
                  ))}
              </div>
          </div>
      </section>

      {/* --- PRICING --- */}
      <section id="pricing" className="py-24 bg-white">
        <div className="container mx-auto px-6">
            <div className="text-center mb-20">
                <h2 className="text-3xl md:text-4xl font-extrabold text-[#111827]">استثمر بذكاء</h2>
                <p className="text-gray-500 mt-4 text-xl">أسعار تنافسية جداً مقارنة بتوظيف موظف خدمة عملاء.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto items-center">
                {/* Starter Plan */}
                <div className="bg-white border border-gray-100 rounded-3xl p-10 hover:shadow-xl transition-shadow">
                    <h3 className="text-2xl font-bold mb-2 text-[#111827]">الباقة الأساسية</h3>
                    <p className="text-gray-500 mb-8">جرب الخدمة وشوف الأثر بنفسك.</p>
                    <div className="flex items-baseline gap-1 mb-8">
                        <span className="text-6xl font-bold text-[#111827]">9</span>
                        <span className="text-2xl text-gray-500">ر.س / شهرياً</span>
                    </div>
                    <ul className="space-y-5 mb-10">
                        <li className="flex items-center gap-4 text-gray-700"><div className="bg-green-100 p-1 rounded-full"><CheckIcon /></div> 100 محادثة شهرياً</li>
                        <li className="flex items-center gap-4 text-gray-700"><div className="bg-green-100 p-1 rounded-full"><CheckIcon /></div> زر عائم (شعار ربّاح)</li>
                        <li className="flex items-center gap-4 text-gray-700"><div className="bg-green-100 p-1 rounded-full"><CheckIcon /></div> دعم فني عبر البريد</li>
                    </ul>
                    <a href="https://bazaarriyadh.com/products/الباقة-الأساسية-الزر-العائم" target="_blank" rel="noopener noreferrer" className="w-full block py-4 bg-gray-50 text-[#111827] rounded-xl text-center font-bold hover:bg-gray-100 transition-colors border border-gray-200">
                        اشترك الآن
                    </a>
                </div>

                {/* Pro Plan */}
                <div className="bg-gradient-to-b from-[#7B61FF] to-[#5f41f2] rounded-3xl p-10 relative shadow-2xl transform md:scale-105 text-white z-10">
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-yellow-400 text-[#111827] px-6 py-2 rounded-full text-sm font-black uppercase tracking-wide shadow-lg">
                        الأكثر مبيعاً
                    </div>
                    <h3 className="text-3xl font-bold mb-2">باقة الانطلاق</h3>
                    <p className="text-purple-100 mb-8">الحل المتكامل للنمو وزيادة المبيعات.</p>
                    <div className="flex items-baseline gap-1 mb-8">
                        <span className="text-7xl font-bold">29</span>
                        <span className="text-2xl text-purple-200">ر.س / شهرياً</span>
                    </div>
                    <ul className="space-y-5 mb-10">
                        <li className="flex items-center gap-4 font-bold"><div className="bg-white/20 p-1 rounded-full"><CheckIcon /></div> محادثات لا محدودة</li>
                        <li className="flex items-center gap-4"><div className="bg-white/20 p-1 rounded-full"><CheckIcon /></div> إزالة شعار ربّاح</li>
                        <li className="flex items-center gap-4"><div className="bg-white/20 p-1 rounded-full"><CheckIcon /></div> تخصيص كامل للألوان</li>
                        <li className="flex items-center gap-4"><div className="bg-white/20 p-1 rounded-full"><CheckIcon /></div> تقارير وتحليلات متقدمة</li>
                    </ul>
                    <a href="https://bazaarriyadh.com/products/باقة-الانطلاق-الزر-العائم" target="_blank" rel="noopener noreferrer" className="w-full block py-4 bg-white text-[#7B61FF] rounded-xl text-center font-bold hover:bg-gray-50 transition-colors shadow-lg">
                        اشترك الآن
                    </a>
                </div>
            </div>
        </div>
      </section>

      {/* --- FAQ --- */}
      <section id="faq" className="py-24 bg-[#F8F9FC]">
        <div className="container mx-auto px-6 max-w-4xl">
            <div className="text-center mb-16">
                <h2 className="text-3xl md:text-4xl font-extrabold text-[#111827]">الأسئلة الشائعة</h2>
            </div>
            
            <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8">
                <FAQItem question="هل هذا تطبيق منفصل لازم العميل يحمله؟" answer="لا، أبداً. ربّاح هو (Widget) أو إضافة برمجية تظهر كزر عائم داخل موقعك الإلكتروني. العميل ما يحتاج يحمل أي شي." />
                <FAQItem question="كيف أركبه في متجري؟" answer="بعد الاشتراك، نعطيك كود بسيط (أو نربط مباشرة مع زد وسلة) يخلي الزر يظهر تلقائياً في كل صفحات متجرك." />
                <FAQItem question="هل يتعارض مع تصميم متجري؟" answer="لا، الزر مصمم يكون أنيق وغير مزعج، وتقدر تتحكم في لونه ومكانه عشان يتناسب مع هوية متجرك." />
                <FAQItem question="هل البوت يسحب بياناتي؟" answer="البوت يقرأ فقط معلومات المنتجات المتاحة للعامة عشان يقدر يجاوب العملاء، ولا يدخل في البيانات الخاصة أو الحساسة." />
            </div>
        </div>
      </section>

      {/* --- CONTACT --- */}
      <section id="contact" className="py-24 bg-white">
          <div className="container mx-auto px-6 max-w-2xl">
              <div className="text-center mb-12">
                  <h2 className="text-3xl md:text-4xl font-extrabold text-[#111827]">تواصل معنا</h2>
                  <p className="text-gray-500 mt-4">عندك سؤال أو استفسار؟ حنا هنا عشان نسمعك.</p>
              </div>

               <a 
                href="https://wa.me/966559042811" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-3 w-full py-4 mb-8 bg-[#25D366] text-white font-bold rounded-xl hover:bg-[#20bd5a] transition-colors shadow-lg"
               >
                 <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                </svg>
                تواصل معنا عبر واتساب
              </a>

              <div className="relative flex py-2 items-center mb-8">
                <div className="flex-grow border-t border-gray-200"></div>
                <span className="flex-shrink-0 mx-4 text-gray-400 text-sm">أو راسلنا عبر البريد</span>
                <div className="flex-grow border-t border-gray-200"></div>
              </div>
              
              <form onSubmit={handleContactSubmit} className="space-y-6">
                  <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">الاسم</label>
                      <input type="text" id="name" required className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-[#7B61FF] focus:border-transparent transition-all outline-none" />
                  </div>
                  <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">البريد الإلكتروني</label>
                      <input type="email" id="email" required className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-[#7B61FF] focus:border-transparent transition-all outline-none" />
                  </div>
                  <div>
                      <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">الرسالة</label>
                      <textarea id="message" rows={4} required className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-[#7B61FF] focus:border-transparent transition-all outline-none"></textarea>
                  </div>
                  <button type="submit" className="w-full py-4 bg-[#111827] text-white font-bold rounded-xl hover:bg-black transition-colors shadow-lg">
                      إرسال الرسالة
                  </button>
              </form>
          </div>
      </section>
    </div>
  );
};

export default HomePage;

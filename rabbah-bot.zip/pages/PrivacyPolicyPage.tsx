
import React from 'react';

const PrivacyPolicyPage: React.FC = () => {
  return (
    <div className="bg-white py-16">
      <div className="container mx-auto px-6 max-w-4xl">
        <h1 className="text-3xl md:text-4xl font-bold text-[#111827] mb-4 text-center">سياسة الخصوصية</h1>
        <h2 className="text-xl md:text-2xl font-semibold text-[#7B61FF] mb-8 text-center">منصّة ربّاح وبوت الزر العائم</h2>
        
        <div className="prose prose-lg text-[#6B7280] mx-auto text-right leading-relaxed space-y-8">
          
          <p>
            نحن في منصّة ربّاح نحرص على خصوصيتك، ونحاول قدر المستطاع نحافظ على بياناتك ونستخدمها في أضيق الحدود لخدمتك فقط.
            <br />
            باستخدامك لموقعنا أو لبوت الزر العائم، فأنت توافق على سياسة الخصوصية هذه.
          </p>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">١. من نحن؟</h3>
            <ul className="list-disc list-inside space-y-2 marker:text-[#7B61FF]">
              <li><strong className="text-[#111827]">منصّة ربّاح:</strong> منصّة تساعد التجّار بأدوات مثل الحاسبات، البوت الذكي، وربط المتاجر بالخدمات المختلفة.</li>
              <li><strong className="text-[#111827]">بوت الزر العائم:</strong> مساعد ذكي يظهر كزر في موقع المتجر، يرد على أسئلة العملاء ويساعدهم.</li>
            </ul>
            <p className="mt-4">كل هدفنا: نخدمك ونطوّر خدماتنا بدون ما نسيء استخدام بياناتك.</p>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">٢. ما البيانات التي قد نجمعها؟</h3>
            <p>نأخذ أقل قدر ممكن من البيانات، مثل:</p>
            <ul className="list-disc list-inside space-y-2 mt-2 marker:text-[#7B61FF]">
              <li>اسمك أو اسم متجرك (إذا أعطيته لنا).</li>
              <li>رقم جوالك أو بريدك الإلكتروني (لو كتبته بنفسك داخل النماذج أو مع البوت).</li>
              <li>مدينتك أو دولتك (إن ذكرتها في الحديث أو النماذج).</li>
              <li>رسائلك مع البوت (الأسئلة والأجوبة) لتحسين الخدمة وفهم احتياجات العملاء.</li>
              <li>بعض المعلومات التقنية البسيطة عن زيارتك (نوع المتصفح، وقت الدخول… إلخ) عشان نعرف هل الموقع يشتغل بشكل سليم للجميع.</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">٣. ليه نستخدم بياناتك؟</h3>
            <p>نستخدم بياناتك لأسباب واضحة وبسيطة:</p>
            <ul className="list-disc list-inside space-y-2 mt-2 marker:text-[#7B61FF]">
              <li>تشغيل البوت والرد على أسئلتك.</li>
              <li>تحسين مستوى الردود والخدمة.</li>
              <li>مساعدتك في ربط متجرك مع أدوات منصّة ربّاح (مثل الحاسبات أو الويب هوكات).</li>
              <li>التواصل معك عند الحاجة (مثلاً لو فيه مشكلة في اشتراكك أو تحديث مهم).</li>
            </ul>
            <p className="mt-4 font-medium text-[#111827]">ما نستخدم بياناتك لأي غرض مزعج أو غير واضح.</p>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">٤. مع من قد نشارك بياناتك؟</h3>
            <p>نشارك جزءًا بسيطًا من البيانات فقط إذا احتجنا لذلك لتشغيل الخدمة، مثل:</p>
            <ul className="list-disc list-inside space-y-2 mt-2 marker:text-[#7B61FF]">
              <li>مزوّدي الاستضافة وقواعد البيانات (عشان الموقع والبوت يشتغلون).</li>
              <li>مزوّد خدمة الذكاء الاصطناعي الذي يساعدنا في توليد الردود للبوت.</li>
            </ul>
            <p className="mt-4">
              نحرص أن تكون هذه الجهات موثوقة، ونشارك أقل قدر ممكن من البيانات، ولا نسمح لهم باستخدامها لأغراضهم الخاصة.
            </p>
            <p className="mt-2 font-bold text-[#111827]">لن نقوم ببيع بياناتك أو تأجيرها لأي جهة.</p>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">٥. كيف نحافظ على بياناتك؟</h3>
            <ul className="list-disc list-inside space-y-2 marker:text-[#7B61FF]">
              <li>نستخدم خدمات استضافة معروفة وآمنة.</li>
              <li>نقيّد الوصول إلى البيانات على الأشخاص المصرَّح لهم فقط داخل منصّة ربّاح.</li>
              <li>نحاول دائمًا تحديث أنظمتنا وتحسينها لحماية بياناتك قدر المستطاع.</li>
            </ul>
            <p className="mt-4 text-sm">
              مع ذلك، الإنترنت بشكل عام ما يكون آمن ١٠٠٪، لذلك ننصحك دائمًا بالحفاظ على سرية بيانات الدخول الخاصة بك وعدم مشاركتها مع أحد.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">٦. حقوقك</h3>
            <p>من حقك دائمًا:</p>
            <ul className="list-disc list-inside space-y-2 mt-2 marker:text-[#7B61FF]">
              <li>تسألنا: وش البيانات اللي عندكم عني؟</li>
              <li>تطلب تعديل أي بيانات تشوفها غير صحيحة.</li>
              <li>تطلب حذف بيانات معيّنة إذا ما عاد فيه حاجة لها (قدر المستطاع فنيًا ونظاميًا).</li>
            </ul>
            <p className="mt-4">كل اللي عليك تسويه، تراسلنا بأي وقت وحنحاول نساعدك بما نقدر عليه.</p>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">٧. تغييرات على هذه السياسة</h3>
            <p>
              ممكن نعدّل سياسة الخصوصية من وقت لثاني لو طوّرنا الخدمة أو تغيّرت الأنظمة.
              <br />
              لو حصل تعديل مهم، راح نحدّث التاريخ أعلى الصفحة، وقد نذكرك به إن احتجنا.
            </p>
            <p className="mt-4 font-medium">
              استمرارك في استخدام منصّة ربّاح أو البوت يعني موافقتك على أحدث نسخة من السياسة.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">٨. كيف تتواصل معنا؟</h3>
            <p>لو عندك أي سؤال أو ملاحظة عن الخصوصية أو بياناتك، تقدر تتواصل معنا:</p>
            <div className="mt-4 bg-gray-50 p-4 rounded-lg border border-gray-100">
              <ul className="space-y-2">
                <li className="flex items-center">
                  <span className="font-bold ml-2 text-[#111827]">رقم الجوال / واتساب:</span>
                  <span dir="ltr" className="text-[#7B61FF] font-medium">+966559042811</span>
                </li>
                <li className="flex items-center">
                  <span className="font-bold ml-2 text-[#111827]">البريد الإلكتروني:</span>
                  <a href="mailto:osamagoore@gmail.com" className="text-[#7B61FF] font-medium hover:underline">osamagoore@gmail.com</a>
                </li>
              </ul>
            </div>
          </section>

          <div className="mt-12 pt-8 border-t border-gray-200 text-center">
            <p className="font-bold text-[#111827]">
              نسعد بأي استفسار أو ملاحظة، وهدفنا دائمًا إن التجربة تكون مريحة وآمنة لك.
            </p>
          </div>

        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicyPage;


import React from 'react';

const TermsOfServicePage: React.FC = () => {
  return (
    <div className="bg-white py-16">
      <div className="container mx-auto px-6 max-w-4xl">
        <h1 className="text-3xl md:text-4xl font-bold text-[#111827] mb-4 text-center">سياسة استخدام بوت الزر العائم (البوت الذكي)</h1>
        <h2 className="text-xl md:text-2xl font-semibold text-[#7B61FF] mb-8 text-center">التابع لمنصّة ربّاح</h2>
        
        <div className="prose prose-lg text-[#6B7280] mx-auto text-right leading-relaxed space-y-8">
          
          <div className="text-sm text-gray-400 text-center mb-8">
            آخر تحديث: ١٨ نوفمبر ٢٠٢٥م
          </div>

          <p>
            مرحبًا بك في بوت الزر العائم (البوت الذكي) التابع لـ منصّة ربّاح.
            باستخدامك للبوت، فأنت توافق على سياسة الاستخدام التالية، لذا يُرجى قراءتها بعناية قبل البدء.
          </p>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">١. التعريفات</h3>
            <p>لأغراض هذه السياسة، يكون للمصطلحات التالية المعاني المبينة قرين كل منها:</p>
            <ul className="list-disc list-inside space-y-2 mt-4 marker:text-[#7B61FF]">
              <li><strong className="text-[#111827]">البوت / بوت الزر العائم:</strong> نظام محادثة آلي مدعوم بالذكاء الاصطناعي يظهر كزر عائم في موقع وخدمات منصّة ربّاح ويقدّم إجابات ومساعدة للعملاء.</li>
              <li><strong className="text-[#111827]">المستخدم / العميل:</strong> كل شخص يقوم باستخدام البوت أو يتفاعل معه.</li>
              <li><strong className="text-[#111827]">المنصّة / ربّاح:</strong> موقع وخدمات منصّة ربّاح الإلكترونية، بما في ذلك جميع الصفحات والأدوات والخدمات التابعة لها.</li>
              <li><strong className="text-[#111827]">المحتوى:</strong> أي نص أو بيانات أو أسئلة أو رسائل يرسلها المستخدم إلى البوت، وأي ردود أو مخرجات يصدرها البوت.</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">٢. قبول سياسة الاستخدام</h3>
            <ul className="list-disc list-inside space-y-2 marker:text-[#7B61FF]">
              <li>استخدامك للبوت يعني موافقتك الكاملة وغير المشروطة على هذه السياسة.</li>
              <li>في حال عدم موافقتك على أي جزء من هذه السياسة، يُرجى عدم استخدام البوت.</li>
              <li>تحتفظ منصّة ربّاح بالحق في تعديل سياسة الاستخدام في أي وقت، ويتم نشر التعديل في هذه الصفحة، ويُعتبر استمرارك في استخدام البوت بعد التعديل موافقة ضمنية على الشروط المحدثة.</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">٣. طبيعة عمل البوت وحدود مسؤوليته</h3>
            <p>يعمل البوت لأغراض المساعدة العامة والإرشاد فقط؛ مثل:</p>
            <ul className="list-disc list-inside space-y-2 mt-2 marker:text-[#7B61FF]">
              <li>الإجابة على الأسئلة عن المنتجات أو الخدمات.</li>
              <li>توضيح طريقة استخدام أدوات منصّة ربّاح.</li>
              <li>تقديم معلومات عن الأسعار، الشحن، الطلبات، وغير ذلك حسب إعدادات المنصّة.</li>
            </ul>
            <p className="mt-4">
              رغم سعي منصّة ربّاح لأن تكون المعلومات التي يقدّمها البوت دقيقة ومحدثة، قد تتضمن الردود أحيانًا أخطاء أو معلومات غير مكتملة، ولا يُعدّ ذلك استشارة رسمية أو التزامًا تعاقديًا.
            </p>
            <p className="mt-4">
              يجب على المستخدم عدم الاعتماد الكامل على ردود البوت في القرارات المهمة (مثل القرارات المالية أو القانونية أو الصحية)، وعليه التحقق من المعلومات عبر القنوات الرسمية أو التواصل مع فريق الدعم.
            </p>
            <p className="mt-4">لا تتحمّل منصّة ربّاح أي مسؤولية عن:</p>
            <ul className="list-disc list-inside space-y-2 mt-2 marker:text-[#7B61FF]">
              <li>أي ضرر مباشر أو غير مباشر ينتج عن الاعتماد على ردود البوت.</li>
              <li>أي سوء فهم أو تفسير خاطئ لرسائل البوت من قِبل المستخدم.</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">٤. استخدام البوت استخدامًا مشروعًا</h3>
            <p>يلتزم المستخدم عند استخدام البوت بما يلي:</p>
            
            <div className="mt-4">
              <h4 className="font-bold text-[#111827]">عدم إرسال أي محتوى:</h4>
              <ul className="list-disc list-inside space-y-2 mt-2 marker:text-[#7B61FF]">
                <li>مخالف للأنظمة أو القوانين المعمول بها في بلد المستخدم أو بلد تشغيل المنصّة.</li>
                <li>يتضمن ألفاظًا نابية، عنصرية، مسيئة، مهينة، تهديدية، أو يحرض على العنف أو الكراهية.</li>
                <li>يحتوي على مواد إباحية، أو محتوى غير لائق، أو مخالف للآداب العامة.</li>
                <li>يتضمن فيروسات، أو روابط خبيثة، أو أي شيفرات تهدف إلى الإضرار بالموقع أو أنظمة المنصّة أو المستخدمين الآخرين.</li>
              </ul>
            </div>

            <div className="mt-4">
              <h4 className="font-bold text-[#111827]">عدم استخدام البوت في:</h4>
              <ul className="list-disc list-inside space-y-2 mt-2 marker:text-[#7B61FF]">
                <li>انتحال شخصية أي فرد أو جهة.</li>
                <li>إرسال رسائل دعائية غير مرغوب فيها (Spam) أو محاولات احتيال.</li>
                <li>أي نشاط يُعدّ تعدّيًا على خصوصية الآخرين أو حقوقهم.</li>
              </ul>
            </div>
            
            <p className="mt-4 font-medium">
              تحتفظ منصّة ربّاح بالحق في إيقاف أو حجب استخدام البوت عن أي مستخدم يسيء استخدام الخدمة أو يخالف هذه الشروط.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">٥. دقة البيانات والمعلومات</h3>
            <ul className="list-disc list-inside space-y-2 marker:text-[#7B61FF]">
              <li>قد يطلب البوت من المستخدم تزويده ببعض البيانات، مثل: الاسم، المدينة، رابط المتجر، نوع الاستفسار، رقم الطلب، وغيرها حسب الحاجة.</li>
              <li>يقرّ المستخدم بأن جميع المعلومات التي يقدّمها صحيحة وكاملة وحديثة قدر الإمكان.</li>
              <li>لا تتحمّل منصّة ربّاح أي مسؤولية عن أي ضرر ناتج عن تقديم بيانات خاطئة أو غير دقيقة من قِبل المستخدم.</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">٦. الخصوصية وحماية البيانات</h3>
            <p>قد يتم تخزين المحادثات مع البوت وبيانات المستخدم لأغراض، منها:</p>
            <ul className="list-disc list-inside space-y-2 mt-2 marker:text-[#7B61FF]">
              <li>تحسين جودة الخدمة وتطوير أداء البوت.</li>
              <li>تحليل الاستفسارات الشائعة لتحسين تجربة المستخدم.</li>
              <li>الربط مع أنظمة أخرى (مثل نظام الطلبات، أتمتة الواتساب، أو أنظمة خارجية عبر Webhooks) وفق إعدادات منصّة ربّاح.</li>
            </ul>
            <p className="mt-4">
              يتم التعامل مع بيانات المستخدم وفقًا لـ <span className="text-[#7B61FF] font-bold">سياسة الخصوصية</span> الخاصة بمنصّة ربّاح، والتي يمكن الاطلاع عليها عبر صفحة "سياسة الخصوصية" في موقع المنصّة.
            </p>
            <p className="mt-2">
              باستخدامك للبوت، فإنك توافق على جمع ومعالجة واستخدام بياناتك بالطريقة الموضحة في سياسة الخصوصية وهذه السياسة.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">٧. الملكية الفكرية</h3>
            <ul className="list-disc list-inside space-y-2 marker:text-[#7B61FF]">
              <li>جميع النصوص، والرسوم، والتصاميم، وواجهة البوت، والشعار، وأي مكونات بصرية أو نصية مرتبطة بالبوت أو بمنصّة ربّاح، هي مملوكة لـ منصّة ربّاح أو للجهات المرخِّصة لها، ومحميّة بموجب قوانين الملكية الفكرية المعمول بها.</li>
              <li>يُحظر نسخ أو إعادة استخدام أو بيع أو تعديل أي جزء من البوت أو مخرجاته لأغراض تجارية، إلا بعد الحصول على موافقة خطية مسبقة من منصّة ربّاح.</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">٨. التكامل مع أنظمة وخدمات أخرى</h3>
            <p>قد يكون البوت متكاملًا مع أنظمة أو خدمات أخرى، مثل:</p>
            <ul className="list-disc list-inside space-y-2 mt-2 marker:text-[#7B61FF]">
              <li>أنظمة الدفع.</li>
              <li>أنظمة إدارة الطلبات.</li>
              <li>أنظمة الرسائل (مثل الواتساب أو التليجرام).</li>
              <li>أو منصّات خارجية عبر Webhooks.</li>
            </ul>
            <p className="mt-4">
              لا تتحمّل منصّة ربّاح مسؤولية أي أعطال أو أخطاء ناتجة عن خدمات أو أنظمة خارجية لا تملكها أو لا تديرها مباشرة.
            </p>
            <p className="mt-2">
              تخضع أي خدمات أو أنظمة خارجية لشروط الاستخدام والسياسات الخاصة بتلك الخدمات.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">٩. التعديلات على الخدمة أو إيقافها</h3>
            <p>تحتفظ منصّة ربّاح بالحق في:</p>
            <ul className="list-disc list-inside space-y-2 mt-2 marker:text-[#7B61FF]">
              <li>إضافة أو إزالة أو تعديل أي خصائص أو ميزات في البوت في أي وقت.</li>
              <li>إيقاف البوت مؤقتًا أو نهائيًا، سواءً لأغراض الصيانة أو التطوير أو لأي أسباب أخرى،</li>
            </ul>
            <p className="mt-2">
              وذلك مع عدم الإخلال بمسؤولية والتزامات المشتركين عن سداد أي مبالغ مستحقة أو الالتزام بالشروط المتفق عليها حتى تاريخ انتهاء أو إلغاء اشتراكهم النظامي.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">١٠. القانون المعمول به</h3>
            <ul className="list-disc list-inside space-y-2 marker:text-[#7B61FF]">
              <li>تخضع هذه السياسة وتُفسَّر وفقًا للأنظمة والقوانين المعمول بها في المملكة العربية السعودية.</li>
              <li>في حال نشوء أي خلاف أو نزاع يتعلق باستخدام البوت، فيُسعى قدر الإمكان لحلّه بالطرق الودية بين منصّة ربّاح والمستخدم.</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-bold text-[#111827] mb-4">١١. التواصل والاستفسارات</h3>
            <p>لأي استفسار يتعلق بسياسة استخدام البوت أو بطريقة عمله، يمكن التواصل مع منصّة ربّاح عبر:</p>
            <div className="mt-4 bg-gray-50 p-4 rounded-lg border border-gray-100">
              <ul className="space-y-2">
                <li className="flex items-center">
                  <span className="font-bold ml-2 text-[#111827]">رقم الجوال / واتساب:</span>
                  <span dir="ltr" className="text-[#7B61FF] font-medium">+966559042811</span>
                </li>
                <li className="flex items-center">
                  <span className="font-bold ml-2 text-[#111827]">البريد الإلكتروني:</span>
                  <a href="mailto:osamagoore@gmail.com" className="text-[#7B61FF] font-medium hover:underline">osamagoore@gmail.com</a>
                </li>
                <li>
                  <span className="font-bold ml-2 text-[#111827]">أو عبر صفحة "اتصل بنا" في موقع منصّة ربّاح</span>
                </li>
              </ul>
            </div>
          </section>

          <div className="mt-12 pt-8 border-t border-gray-200 text-center">
            <p className="font-bold text-[#111827]">
              باستخدامك لبوت الزر العائم الخاص بمنصّة ربّاح، فإنك تقرّ بأنك قرأت وفهمت ووافقت على جميع الأحكام الواردة في هذه السياسة.
            </p>
          </div>

        </div>
      </div>
    </div>
  );
};

export default TermsOfServicePage;

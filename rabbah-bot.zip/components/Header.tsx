import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { name: 'الرئيسية', href: '#hero' },
    { name: 'المزايا', href: '#features' },
    { name: 'الأسعار', href: '#pricing' },
    { name: 'الأسئلة الشائعة', href: '#faq' },
    { name: 'تواصل معنا', href: '#contact' },
  ];

  return (
    <header className="bg-white/90 backdrop-blur-lg sticky top-0 z-50 shadow-sm border-b border-gray-100">
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <Link to="/#hero" className="text-2xl font-extrabold gradient-text">
          ربّاح بوت
        </Link>
        <nav className="hidden md:flex items-center space-x-8 rtl:space-x-reverse">
          {navLinks.map((link) => (
            <Link key={link.name} to={`/${link.href}`} className="text-[#6B7280] hover:text-[#7B61FF] transition-colors font-medium">
              {link.name}
            </Link>
          ))}
        </nav>
        <div className="hidden md:block">
          <Link to="/#pricing" className="bg-[#7B61FF] text-white font-bold py-2 px-6 rounded-lg transition-all hover:scale-105 shadow-lg hover:shadow-xl hover:shadow-[#7B61FF]/40">
            ركّب البوت الآن
          </Link>
        </div>
        <div className="md:hidden">
          <button onClick={() => setIsOpen(!isOpen)} className="text-[#111827] focus:outline-none">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={isOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16m-7 6h7"}></path>
            </svg>
          </button>
        </div>
      </div>
      {isOpen && (
        <div className="md:hidden bg-white pb-4 border-t border-gray-100">
          <nav className="flex flex-col items-center space-y-4 pt-4">
            {navLinks.map((link) => (
              <Link key={link.name} to={`/${link.href}`} onClick={() => setIsOpen(false)} className="text-[#6B7280] hover:text-[#7B61FF] transition-colors py-2">
                {link.name}
              </Link>
            ))}
            <Link to="/#pricing" onClick={() => setIsOpen(false)} className="bg-[#7B61FF] text-white font-bold py-2 px-8 rounded-lg hover:bg-[#6b53e3] transition-transform hover:scale-105 shadow-lg w-auto">
              ركّب البوت الآن
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
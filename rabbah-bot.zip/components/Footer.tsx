import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#111827] text-white">
      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center md:text-right">
          <div className="md:col-span-1">
            <h3 className="text-2xl font-extrabold gradient-text">ربّاح بوت</h3>
            <p className="mt-2 text-[#9CA3AF]">
              جعل كل متجر عربي قادراً على خدمة عملائه آلياً وباحترافية.
            </p>
          </div>
          <div/>
          <div>
            <h4 className="font-bold text-lg text-white">روابط سريعة</h4>
            <ul className="mt-4 space-y-2">
              <li><Link to="/#features" className="text-[#9CA3AF] hover:text-[#22D3EE]">المزايا</Link></li>
              <li><Link to="/#pricing" className="text-[#9CA3AF] hover:text-[#22D3EE]">الأسعار</Link></li>
              <li><Link to="/#faq" className="text-[#9CA3AF] hover:text-[#22D3EE]">الأسئلة الشائعة</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-lg text-white">قانوني</h4>
            <ul className="mt-4 space-y-2">
              <li><Link to="/privacy" className="text-[#9CA3AF] hover:text-[#22D3EE]">سياسة الخصوصية</Link></li>
              <li><Link to="/terms" className="text-[#9CA3AF] hover:text-[#22D3EE]">شروط الاستخدام</Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-12 border-t border-gray-800 pt-8 text-center text-gray-500">
          <p>&copy; {new Date().getFullYear()} ربّاح بوت. جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;